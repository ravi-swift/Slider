//
//  ViewController.swift
//  Slider
//
//  Created by Rp on 28/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var slider : UISlider!
    @IBOutlet var lbl : UILabel!
    
    let sliderSecound = UISlider()
    let lblSecound = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        sliderSecound.frame = CGRect.init(x: 30, y: 500, width: UIScreen.main.bounds.size.width-60, height: 30)
        sliderSecound.maximumTrackTintColor = UIColor.red
        sliderSecound.minimumTrackTintColor = UIColor.black
        sliderSecound.thumbTintColor = UIColor.green
        sliderSecound.addTarget(self, action: #selector(valueChange(slider:)), for: .valueChanged)
        view.addSubview(sliderSecound)
        
        lblSecound.frame = CGRect.init(x: (UIScreen.main.bounds.size.width)/2, y: 450, width: 50, height: 30)
        lblSecound.textColor = UIColor.black
        view.addSubview(lblSecound)
        
    }
    
    @IBAction func sliderChange(slider:UISlider){
        print(slider.value)
        let final = slider.value * 100
        lbl.text = String.init(format: "%.0f%%", final)
    }
    
    @objc func valueChange(slider:UISlider){
        print(sliderSecound.value)
        let final = sliderSecound.value * 100
        lblSecound.text = String.init(format: "%.0f%%", final)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

